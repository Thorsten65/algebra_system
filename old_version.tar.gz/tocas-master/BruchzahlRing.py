from AbstrakteRinge import *


class BruchzahlRing(Ring):

    def __init__(self, info):
        pass

    def element(self, *info):
        pass

    def __str__(self):
        pass


class BruchzahlRing(RingElement):

    def __init__(self, elementinfo, ringinfo, zusatz=None):
        pass

    def drucke_element(self):
        pass

    def __eq__(self, other):
        pass

    def __neg__(self):
        pass

    def __rmul__(self, other):
        pass

    def invers(self):
        pass
